<? include('header.php') ?>
    <div class="banner_sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="breadcrumbs-area sec-heading">
                        <div class="sub-inner mb-15">
                        </div>
                        <h2 class="title mb-0">Pools</h2>
                    </div>
                </div>
                <div class="col-lg-7 breadcrumbs-form md-mt-30">
                </div>
            </div>
        </div>
    </div>

    <div class="leaderboard pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <table class="table Period_sec">
                        <thead>
                            <tr>
                                <th scope="col">Pool</th>
                                <th scope="col">APY</th>
                                <th scope="col">Lockup Period</th>
                                <th scope="col">Your Balance</th>
                                 <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody id="pools-list">
                            <!--<tr class="del">-->
                            <!--    <td>USDT Pool</td>-->
                            <!--    <td>12%</td>-->
                            <!--    <td>50 Days</td>-->
                            <!--    <td> $0.10</td>-->
                            <!--    <td><button class="repaid"> Repaid </button></td>-->
                            <!--</tr>-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="index.js?v=<? echo filemtime('index.js'); ?>"></script>
<? include('footer.php') ?>