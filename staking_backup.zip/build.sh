#!/usr/bin/env bash
set -Eeuo

mkdir -p dist
rm -rf dist/*
rsync -qav . dist/ --exclude ".git" --exclude ".vscode" --exclude "dist"

# Can also use the below lines if supported
# shopt -s extglob
# cp -R ./!(.git|.vscode|dist) ./dist
