<?php
$server = "test"; // available choices: "test" and "main"

$link;
if ($server == "main") {
  $link = mysqli_connect("localhost", "myreview_staking_newdemo", "u[K=NI.u7zG[", "myreview_staking_newdemo");
} else {
  $link = mysqli_connect("localhost", "myreview_staking_newdemo", "u[K=NI.u7zG[", "myreview_staking_newdemo");
}

if (!$link) {
  echo mysqli_connect_errno() . ":" . mysqli_connect_error();
  exit;
}