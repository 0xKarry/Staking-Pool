<?php
include("../api/config.php");

$id = $_POST['id'];
$price = $_POST['price'];

$update = mysqli_query($link, "UPDATE nft_collections SET price='$price' WHERE  id='$id'");

if($update){
    header('X-PHP-Response-Code: 200', true, 200);
    echo json_encode(array("code"=>200,"message"=>"Collection Price Updated Successfully"));
}else{
    header('X-PHP-Response-Code: 500', true, 500);
    echo json_encode(array("code"=>500,"message"=>"Internel Server Error"));
}

?>